﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.tabControl1 = New System.Windows.Forms.TabControl()
        Me.tabAthlete = New System.Windows.Forms.TabPage()
        Me.cboBoxCtyAth4 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth10 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth9 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth8 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth7 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth6 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth5 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth2 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth3 = New System.Windows.Forms.ComboBox()
        Me.cboBoxCtyAth1 = New System.Windows.Forms.ComboBox()
        Me.btnMark = New System.Windows.Forms.Button()
        Me.grpAthletes = New System.Windows.Forms.GroupBox()
        Me.lblSelectAth = New System.Windows.Forms.Label()
        Me.rdoNoOfAthBtn10 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn9 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn8 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn7 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn6 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn5 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn4 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn3 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn2 = New System.Windows.Forms.RadioButton()
        Me.rdoNoOfAthBtn1 = New System.Windows.Forms.RadioButton()
        Me.lblCountyheading = New System.Windows.Forms.Label()
        Me.lblAthheading = New System.Windows.Forms.Label()
        Me.txtBoxAthName10 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName9 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName8 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName7 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName6 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName5 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName4 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName3 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName2 = New System.Windows.Forms.TextBox()
        Me.txtBoxAthName1 = New System.Windows.Forms.TextBox()
        Me.tabRankings = New System.Windows.Forms.TabPage()
        Me.btnAwards = New System.Windows.Forms.Button()
        Me.lstBoxFinish = New System.Windows.Forms.ListBox()
        Me.lblColon2 = New System.Windows.Forms.Label()
        Me.lblColon1 = New System.Windows.Forms.Label()
        Me.lblMinutes = New System.Windows.Forms.Label()
        Me.lblSeconds = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.lblHours = New System.Windows.Forms.Label()
        Me.tabStandings = New System.Windows.Forms.TabPage()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.picBox2ndPlace = New System.Windows.Forms.PictureBox()
        Me.picBox3rdPlace = New System.Windows.Forms.PictureBox()
        Me.picBox4thPlace = New System.Windows.Forms.PictureBox()
        Me.picBox5thPlace = New System.Windows.Forms.PictureBox()
        Me.picBox6thPlace = New System.Windows.Forms.PictureBox()
        Me.picBox7thPlace = New System.Windows.Forms.PictureBox()
        Me.picBox8thPlace = New System.Windows.Forms.PictureBox()
        Me.picBox9thPlace = New System.Windows.Forms.PictureBox()
        Me.picBox10thPlace = New System.Windows.Forms.PictureBox()
        Me.picBox1stPlace = New System.Windows.Forms.PictureBox()
        Me.lbl10thCol = New System.Windows.Forms.Label()
        Me.lbl10thColon = New System.Windows.Forms.Label()
        Me.lbl10thSec = New System.Windows.Forms.Label()
        Me.lbl10thMin = New System.Windows.Forms.Label()
        Me.lbl10thHr = New System.Windows.Forms.Label()
        Me.lbl9thCol = New System.Windows.Forms.Label()
        Me.lbl9thColon = New System.Windows.Forms.Label()
        Me.lbl9thSec = New System.Windows.Forms.Label()
        Me.lbl9thMin = New System.Windows.Forms.Label()
        Me.lbl9thHr = New System.Windows.Forms.Label()
        Me.lbl8thCol = New System.Windows.Forms.Label()
        Me.lbl8thColon = New System.Windows.Forms.Label()
        Me.lbl8thSec = New System.Windows.Forms.Label()
        Me.lbl8thMin = New System.Windows.Forms.Label()
        Me.lbl8thHr = New System.Windows.Forms.Label()
        Me.lbl7thCol = New System.Windows.Forms.Label()
        Me.lbl7thColon = New System.Windows.Forms.Label()
        Me.lbl7thSec = New System.Windows.Forms.Label()
        Me.lbl7thMin = New System.Windows.Forms.Label()
        Me.lbl7thHr = New System.Windows.Forms.Label()
        Me.lbl6thCol = New System.Windows.Forms.Label()
        Me.lbl6thColon = New System.Windows.Forms.Label()
        Me.lbl6thSec = New System.Windows.Forms.Label()
        Me.lbl6thMin = New System.Windows.Forms.Label()
        Me.lbl6thHr = New System.Windows.Forms.Label()
        Me.lbl5thCol = New System.Windows.Forms.Label()
        Me.lbl5thColon = New System.Windows.Forms.Label()
        Me.lbl5thSec = New System.Windows.Forms.Label()
        Me.lbl5thMin = New System.Windows.Forms.Label()
        Me.lbl5thHr = New System.Windows.Forms.Label()
        Me.lbl4thCol = New System.Windows.Forms.Label()
        Me.lbl4thColon = New System.Windows.Forms.Label()
        Me.lbl4thSec = New System.Windows.Forms.Label()
        Me.lbl4thMin = New System.Windows.Forms.Label()
        Me.lbl4thHr = New System.Windows.Forms.Label()
        Me.lbl3rdCol = New System.Windows.Forms.Label()
        Me.lbl3rdColon = New System.Windows.Forms.Label()
        Me.lbl3rdSec = New System.Windows.Forms.Label()
        Me.lbl3rdMin = New System.Windows.Forms.Label()
        Me.lbl3rdHr = New System.Windows.Forms.Label()
        Me.lbl2ndCol = New System.Windows.Forms.Label()
        Me.lbl2ndColon = New System.Windows.Forms.Label()
        Me.lbl2ndSec = New System.Windows.Forms.Label()
        Me.lbl2ndMin = New System.Windows.Forms.Label()
        Me.lbl2ndHr = New System.Windows.Forms.Label()
        Me.lbl1stCol = New System.Windows.Forms.Label()
        Me.lbl1stColon = New System.Windows.Forms.Label()
        Me.lbl1stSec = New System.Windows.Forms.Label()
        Me.lbl1stMin = New System.Windows.Forms.Label()
        Me.lbl1stHr = New System.Windows.Forms.Label()
        Me.txt6thName = New System.Windows.Forms.TextBox()
        Me.txt7thName = New System.Windows.Forms.TextBox()
        Me.txt8thName = New System.Windows.Forms.TextBox()
        Me.txt9thName = New System.Windows.Forms.TextBox()
        Me.txt10thName = New System.Windows.Forms.TextBox()
        Me.txt4thName = New System.Windows.Forms.TextBox()
        Me.txt5thName = New System.Windows.Forms.TextBox()
        Me.txt3rdName = New System.Windows.Forms.TextBox()
        Me.txt2ndName = New System.Windows.Forms.TextBox()
        Me.txt1stName = New System.Windows.Forms.TextBox()
        Me.lbl10thPlace = New System.Windows.Forms.Label()
        Me.lbl9thPlace = New System.Windows.Forms.Label()
        Me.lbl8thPlace = New System.Windows.Forms.Label()
        Me.lbl7thPlace = New System.Windows.Forms.Label()
        Me.lbl6thPlace = New System.Windows.Forms.Label()
        Me.lbl5thPlace = New System.Windows.Forms.Label()
        Me.lbl4thPlace = New System.Windows.Forms.Label()
        Me.lbl3rdPlace = New System.Windows.Forms.Label()
        Me.lbl2ndPlace = New System.Windows.Forms.Label()
        Me.lbl1stPlace = New System.Windows.Forms.Label()
        Me.timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.imageList = New System.Windows.Forms.ImageList(Me.components)
        Me.tabControl1.SuspendLayout()
        Me.tabAthlete.SuspendLayout()
        Me.grpAthletes.SuspendLayout()
        Me.tabRankings.SuspendLayout()
        Me.tabStandings.SuspendLayout()
        CType(Me.picBox2ndPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox3rdPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox4thPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox5thPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox6thPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox7thPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox8thPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox9thPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox10thPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox1stPlace, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tabControl1
        '
        Me.tabControl1.Controls.Add(Me.tabAthlete)
        Me.tabControl1.Controls.Add(Me.tabRankings)
        Me.tabControl1.Controls.Add(Me.tabStandings)
        Me.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabControl1.Location = New System.Drawing.Point(0, 0)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(682, 591)
        Me.tabControl1.TabIndex = 30
        '
        'tabAthlete
        '
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth4)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth10)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth9)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth8)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth7)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth6)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth5)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth2)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth3)
        Me.tabAthlete.Controls.Add(Me.cboBoxCtyAth1)
        Me.tabAthlete.Controls.Add(Me.btnMark)
        Me.tabAthlete.Controls.Add(Me.grpAthletes)
        Me.tabAthlete.Controls.Add(Me.lblCountyheading)
        Me.tabAthlete.Controls.Add(Me.lblAthheading)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName10)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName9)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName8)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName7)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName6)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName5)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName4)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName3)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName2)
        Me.tabAthlete.Controls.Add(Me.txtBoxAthName1)
        Me.tabAthlete.Location = New System.Drawing.Point(4, 22)
        Me.tabAthlete.Name = "tabAthlete"
        Me.tabAthlete.Padding = New System.Windows.Forms.Padding(3)
        Me.tabAthlete.Size = New System.Drawing.Size(674, 565)
        Me.tabAthlete.TabIndex = 0
        Me.tabAthlete.Text = "Athletes"
        Me.tabAthlete.UseVisualStyleBackColor = True
        '
        'cboBoxCtyAth4
        '
        Me.cboBoxCtyAth4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth4.FormattingEnabled = True
        Me.cboBoxCtyAth4.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth4.Location = New System.Drawing.Point(360, 223)
        Me.cboBoxCtyAth4.MaxDropDownItems = 10
        Me.cboBoxCtyAth4.Name = "cboBoxCtyAth4"
        Me.cboBoxCtyAth4.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth4.TabIndex = 8
        Me.cboBoxCtyAth4.Visible = False
        '
        'cboBoxCtyAth10
        '
        Me.cboBoxCtyAth10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth10.FormattingEnabled = True
        Me.cboBoxCtyAth10.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth10.Location = New System.Drawing.Point(360, 438)
        Me.cboBoxCtyAth10.MaxDropDownItems = 10
        Me.cboBoxCtyAth10.Name = "cboBoxCtyAth10"
        Me.cboBoxCtyAth10.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth10.TabIndex = 20
        Me.cboBoxCtyAth10.Visible = False
        '
        'cboBoxCtyAth9
        '
        Me.cboBoxCtyAth9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth9.FormattingEnabled = True
        Me.cboBoxCtyAth9.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth9.Location = New System.Drawing.Point(360, 401)
        Me.cboBoxCtyAth9.MaxDropDownItems = 10
        Me.cboBoxCtyAth9.Name = "cboBoxCtyAth9"
        Me.cboBoxCtyAth9.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth9.TabIndex = 18
        Me.cboBoxCtyAth9.Visible = False
        '
        'cboBoxCtyAth8
        '
        Me.cboBoxCtyAth8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth8.FormattingEnabled = True
        Me.cboBoxCtyAth8.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth8.Location = New System.Drawing.Point(360, 365)
        Me.cboBoxCtyAth8.MaxDropDownItems = 10
        Me.cboBoxCtyAth8.Name = "cboBoxCtyAth8"
        Me.cboBoxCtyAth8.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth8.TabIndex = 16
        Me.cboBoxCtyAth8.Visible = False
        '
        'cboBoxCtyAth7
        '
        Me.cboBoxCtyAth7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth7.FormattingEnabled = True
        Me.cboBoxCtyAth7.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth7.Location = New System.Drawing.Point(360, 329)
        Me.cboBoxCtyAth7.MaxDropDownItems = 10
        Me.cboBoxCtyAth7.Name = "cboBoxCtyAth7"
        Me.cboBoxCtyAth7.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth7.TabIndex = 14
        Me.cboBoxCtyAth7.Visible = False
        '
        'cboBoxCtyAth6
        '
        Me.cboBoxCtyAth6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth6.FormattingEnabled = True
        Me.cboBoxCtyAth6.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth6.Location = New System.Drawing.Point(360, 293)
        Me.cboBoxCtyAth6.MaxDropDownItems = 10
        Me.cboBoxCtyAth6.Name = "cboBoxCtyAth6"
        Me.cboBoxCtyAth6.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth6.TabIndex = 12
        Me.cboBoxCtyAth6.Visible = False
        '
        'cboBoxCtyAth5
        '
        Me.cboBoxCtyAth5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth5.FormattingEnabled = True
        Me.cboBoxCtyAth5.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth5.Location = New System.Drawing.Point(360, 257)
        Me.cboBoxCtyAth5.MaxDropDownItems = 10
        Me.cboBoxCtyAth5.Name = "cboBoxCtyAth5"
        Me.cboBoxCtyAth5.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth5.TabIndex = 10
        Me.cboBoxCtyAth5.Visible = False
        '
        'cboBoxCtyAth2
        '
        Me.cboBoxCtyAth2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth2.FormattingEnabled = True
        Me.cboBoxCtyAth2.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth2.Location = New System.Drawing.Point(360, 150)
        Me.cboBoxCtyAth2.MaxDropDownItems = 10
        Me.cboBoxCtyAth2.Name = "cboBoxCtyAth2"
        Me.cboBoxCtyAth2.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth2.TabIndex = 4
        Me.cboBoxCtyAth2.Visible = False
        '
        'cboBoxCtyAth3
        '
        Me.cboBoxCtyAth3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth3.FormattingEnabled = True
        Me.cboBoxCtyAth3.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth3.Location = New System.Drawing.Point(360, 185)
        Me.cboBoxCtyAth3.MaxDropDownItems = 10
        Me.cboBoxCtyAth3.Name = "cboBoxCtyAth3"
        Me.cboBoxCtyAth3.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth3.TabIndex = 6
        Me.cboBoxCtyAth3.Visible = False
        '
        'cboBoxCtyAth1
        '
        Me.cboBoxCtyAth1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBoxCtyAth1.FormattingEnabled = True
        Me.cboBoxCtyAth1.Items.AddRange(New Object() {"Argentina", "Brazil", "Canada", "China", "Jamaica", "Mexico", "Netherlands", "Russia", "South Africa", "USA"})
        Me.cboBoxCtyAth1.Location = New System.Drawing.Point(360, 114)
        Me.cboBoxCtyAth1.MaxDropDownItems = 10
        Me.cboBoxCtyAth1.Name = "cboBoxCtyAth1"
        Me.cboBoxCtyAth1.Size = New System.Drawing.Size(240, 24)
        Me.cboBoxCtyAth1.TabIndex = 2
        Me.cboBoxCtyAth1.Visible = False
        '
        'btnMark
        '
        Me.btnMark.AutoSize = True
        Me.btnMark.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnMark.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMark.Location = New System.Drawing.Point(238, 476)
        Me.btnMark.Name = "btnMark"
        Me.btnMark.Size = New System.Drawing.Size(196, 60)
        Me.btnMark.TabIndex = 26
        Me.btnMark.Text = "On your marks..." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Get set..."
        Me.btnMark.UseVisualStyleBackColor = True
        '
        'grpAthletes
        '
        Me.grpAthletes.Controls.Add(Me.lblSelectAth)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn10)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn9)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn8)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn7)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn6)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn5)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn4)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn3)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn2)
        Me.grpAthletes.Controls.Add(Me.rdoNoOfAthBtn1)
        Me.grpAthletes.Dock = System.Windows.Forms.DockStyle.Top
        Me.grpAthletes.Location = New System.Drawing.Point(3, 3)
        Me.grpAthletes.Name = "grpAthletes"
        Me.grpAthletes.Size = New System.Drawing.Size(668, 78)
        Me.grpAthletes.TabIndex = 25
        Me.grpAthletes.TabStop = False
        Me.grpAthletes.Text = "Athletes"
        '
        'lblSelectAth
        '
        Me.lblSelectAth.AutoSize = True
        Me.lblSelectAth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectAth.Location = New System.Drawing.Point(47, 15)
        Me.lblSelectAth.Name = "lblSelectAth"
        Me.lblSelectAth.Size = New System.Drawing.Size(347, 20)
        Me.lblSelectAth.TabIndex = 33
        Me.lblSelectAth.Text = "Select the number of particpating athletes"
        Me.lblSelectAth.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblSelectAth.Visible = False
        '
        'rdoNoOfAthBtn10
        '
        Me.rdoNoOfAthBtn10.AutoSize = True
        Me.rdoNoOfAthBtn10.Location = New System.Drawing.Point(564, 47)
        Me.rdoNoOfAthBtn10.Name = "rdoNoOfAthBtn10"
        Me.rdoNoOfAthBtn10.Size = New System.Drawing.Size(37, 17)
        Me.rdoNoOfAthBtn10.TabIndex = 23
        Me.rdoNoOfAthBtn10.TabStop = True
        Me.rdoNoOfAthBtn10.Text = "10"
        Me.rdoNoOfAthBtn10.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn9
        '
        Me.rdoNoOfAthBtn9.AutoSize = True
        Me.rdoNoOfAthBtn9.Location = New System.Drawing.Point(507, 47)
        Me.rdoNoOfAthBtn9.Name = "rdoNoOfAthBtn9"
        Me.rdoNoOfAthBtn9.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn9.TabIndex = 24
        Me.rdoNoOfAthBtn9.TabStop = True
        Me.rdoNoOfAthBtn9.Text = "9"
        Me.rdoNoOfAthBtn9.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn8
        '
        Me.rdoNoOfAthBtn8.AutoSize = True
        Me.rdoNoOfAthBtn8.Location = New System.Drawing.Point(450, 47)
        Me.rdoNoOfAthBtn8.Name = "rdoNoOfAthBtn8"
        Me.rdoNoOfAthBtn8.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn8.TabIndex = 25
        Me.rdoNoOfAthBtn8.TabStop = True
        Me.rdoNoOfAthBtn8.Text = "8"
        Me.rdoNoOfAthBtn8.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn7
        '
        Me.rdoNoOfAthBtn7.AutoSize = True
        Me.rdoNoOfAthBtn7.Location = New System.Drawing.Point(393, 47)
        Me.rdoNoOfAthBtn7.Name = "rdoNoOfAthBtn7"
        Me.rdoNoOfAthBtn7.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn7.TabIndex = 26
        Me.rdoNoOfAthBtn7.TabStop = True
        Me.rdoNoOfAthBtn7.Text = "7"
        Me.rdoNoOfAthBtn7.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn6
        '
        Me.rdoNoOfAthBtn6.AutoSize = True
        Me.rdoNoOfAthBtn6.Location = New System.Drawing.Point(336, 47)
        Me.rdoNoOfAthBtn6.Name = "rdoNoOfAthBtn6"
        Me.rdoNoOfAthBtn6.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn6.TabIndex = 27
        Me.rdoNoOfAthBtn6.TabStop = True
        Me.rdoNoOfAthBtn6.Text = "6"
        Me.rdoNoOfAthBtn6.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn5
        '
        Me.rdoNoOfAthBtn5.AutoSize = True
        Me.rdoNoOfAthBtn5.Location = New System.Drawing.Point(279, 47)
        Me.rdoNoOfAthBtn5.Name = "rdoNoOfAthBtn5"
        Me.rdoNoOfAthBtn5.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn5.TabIndex = 28
        Me.rdoNoOfAthBtn5.TabStop = True
        Me.rdoNoOfAthBtn5.Text = "5"
        Me.rdoNoOfAthBtn5.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn4
        '
        Me.rdoNoOfAthBtn4.AutoSize = True
        Me.rdoNoOfAthBtn4.Location = New System.Drawing.Point(222, 47)
        Me.rdoNoOfAthBtn4.Name = "rdoNoOfAthBtn4"
        Me.rdoNoOfAthBtn4.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn4.TabIndex = 29
        Me.rdoNoOfAthBtn4.TabStop = True
        Me.rdoNoOfAthBtn4.Text = "4"
        Me.rdoNoOfAthBtn4.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn3
        '
        Me.rdoNoOfAthBtn3.AutoSize = True
        Me.rdoNoOfAthBtn3.Location = New System.Drawing.Point(165, 47)
        Me.rdoNoOfAthBtn3.Name = "rdoNoOfAthBtn3"
        Me.rdoNoOfAthBtn3.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn3.TabIndex = 30
        Me.rdoNoOfAthBtn3.TabStop = True
        Me.rdoNoOfAthBtn3.Text = "3"
        Me.rdoNoOfAthBtn3.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn2
        '
        Me.rdoNoOfAthBtn2.AutoSize = True
        Me.rdoNoOfAthBtn2.Location = New System.Drawing.Point(108, 47)
        Me.rdoNoOfAthBtn2.Name = "rdoNoOfAthBtn2"
        Me.rdoNoOfAthBtn2.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn2.TabIndex = 31
        Me.rdoNoOfAthBtn2.TabStop = True
        Me.rdoNoOfAthBtn2.Text = "2"
        Me.rdoNoOfAthBtn2.UseVisualStyleBackColor = True
        '
        'rdoNoOfAthBtn1
        '
        Me.rdoNoOfAthBtn1.AutoSize = True
        Me.rdoNoOfAthBtn1.Location = New System.Drawing.Point(51, 48)
        Me.rdoNoOfAthBtn1.Name = "rdoNoOfAthBtn1"
        Me.rdoNoOfAthBtn1.Size = New System.Drawing.Size(31, 17)
        Me.rdoNoOfAthBtn1.TabIndex = 32
        Me.rdoNoOfAthBtn1.TabStop = True
        Me.rdoNoOfAthBtn1.Text = "1"
        Me.rdoNoOfAthBtn1.UseVisualStyleBackColor = True
        '
        'lblCountyheading
        '
        Me.lblCountyheading.AutoSize = True
        Me.lblCountyheading.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCountyheading.Location = New System.Drawing.Point(392, 87)
        Me.lblCountyheading.Name = "lblCountyheading"
        Me.lblCountyheading.Size = New System.Drawing.Size(176, 16)
        Me.lblCountyheading.TabIndex = 24
        Me.lblCountyheading.Text = "Country (Select from list)"
        Me.lblCountyheading.Visible = False
        '
        'lblAthheading
        '
        Me.lblAthheading.AutoSize = True
        Me.lblAthheading.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAthheading.Location = New System.Drawing.Point(157, 87)
        Me.lblAthheading.Name = "lblAthheading"
        Me.lblAthheading.Size = New System.Drawing.Size(64, 16)
        Me.lblAthheading.TabIndex = 23
        Me.lblAthheading.Text = "Athletes"
        Me.lblAthheading.Visible = False
        '
        'txtBoxAthName10
        '
        Me.txtBoxAthName10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName10.Location = New System.Drawing.Point(75, 438)
        Me.txtBoxAthName10.Name = "txtBoxAthName10"
        Me.txtBoxAthName10.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName10.TabIndex = 19
        Me.txtBoxAthName10.Visible = False
        '
        'txtBoxAthName9
        '
        Me.txtBoxAthName9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName9.Location = New System.Drawing.Point(75, 402)
        Me.txtBoxAthName9.Name = "txtBoxAthName9"
        Me.txtBoxAthName9.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName9.TabIndex = 17
        Me.txtBoxAthName9.Visible = False
        '
        'txtBoxAthName8
        '
        Me.txtBoxAthName8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName8.Location = New System.Drawing.Point(75, 366)
        Me.txtBoxAthName8.Name = "txtBoxAthName8"
        Me.txtBoxAthName8.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName8.TabIndex = 15
        Me.txtBoxAthName8.Visible = False
        '
        'txtBoxAthName7
        '
        Me.txtBoxAthName7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName7.Location = New System.Drawing.Point(75, 330)
        Me.txtBoxAthName7.Name = "txtBoxAthName7"
        Me.txtBoxAthName7.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName7.TabIndex = 13
        Me.txtBoxAthName7.Visible = False
        '
        'txtBoxAthName6
        '
        Me.txtBoxAthName6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName6.Location = New System.Drawing.Point(75, 294)
        Me.txtBoxAthName6.Name = "txtBoxAthName6"
        Me.txtBoxAthName6.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName6.TabIndex = 11
        Me.txtBoxAthName6.Visible = False
        '
        'txtBoxAthName5
        '
        Me.txtBoxAthName5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName5.Location = New System.Drawing.Point(75, 258)
        Me.txtBoxAthName5.Name = "txtBoxAthName5"
        Me.txtBoxAthName5.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName5.TabIndex = 9
        Me.txtBoxAthName5.Visible = False
        '
        'txtBoxAthName4
        '
        Me.txtBoxAthName4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName4.Location = New System.Drawing.Point(75, 222)
        Me.txtBoxAthName4.Name = "txtBoxAthName4"
        Me.txtBoxAthName4.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName4.TabIndex = 7
        Me.txtBoxAthName4.Visible = False
        '
        'txtBoxAthName3
        '
        Me.txtBoxAthName3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName3.Location = New System.Drawing.Point(75, 186)
        Me.txtBoxAthName3.Name = "txtBoxAthName3"
        Me.txtBoxAthName3.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName3.TabIndex = 5
        Me.txtBoxAthName3.Visible = False
        '
        'txtBoxAthName2
        '
        Me.txtBoxAthName2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName2.Location = New System.Drawing.Point(75, 150)
        Me.txtBoxAthName2.Name = "txtBoxAthName2"
        Me.txtBoxAthName2.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName2.TabIndex = 3
        Me.txtBoxAthName2.Visible = False
        '
        'txtBoxAthName1
        '
        Me.txtBoxAthName1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAthName1.Location = New System.Drawing.Point(75, 114)
        Me.txtBoxAthName1.Name = "txtBoxAthName1"
        Me.txtBoxAthName1.Size = New System.Drawing.Size(229, 22)
        Me.txtBoxAthName1.TabIndex = 1
        Me.txtBoxAthName1.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.txtBoxAthName1.Visible = False
        '
        'tabRankings
        '
        Me.tabRankings.Controls.Add(Me.btnAwards)
        Me.tabRankings.Controls.Add(Me.lstBoxFinish)
        Me.tabRankings.Controls.Add(Me.lblColon2)
        Me.tabRankings.Controls.Add(Me.lblColon1)
        Me.tabRankings.Controls.Add(Me.lblMinutes)
        Me.tabRankings.Controls.Add(Me.lblSeconds)
        Me.tabRankings.Controls.Add(Me.btnReset)
        Me.tabRankings.Controls.Add(Me.btnStop)
        Me.tabRankings.Controls.Add(Me.lblHours)
        Me.tabRankings.Location = New System.Drawing.Point(4, 22)
        Me.tabRankings.Name = "tabRankings"
        Me.tabRankings.Padding = New System.Windows.Forms.Padding(3)
        Me.tabRankings.Size = New System.Drawing.Size(674, 565)
        Me.tabRankings.TabIndex = 1
        Me.tabRankings.Text = "Rankings"
        Me.tabRankings.UseVisualStyleBackColor = True
        '
        'btnAwards
        '
        Me.btnAwards.AutoSize = True
        Me.btnAwards.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAwards.Location = New System.Drawing.Point(177, 418)
        Me.btnAwards.Name = "btnAwards"
        Me.btnAwards.Size = New System.Drawing.Size(321, 30)
        Me.btnAwards.TabIndex = 9
        Me.btnAwards.Text = "PROCEED TO AWARDS CEREMONY"
        Me.btnAwards.UseVisualStyleBackColor = True
        Me.btnAwards.Visible = False
        '
        'lstBoxFinish
        '
        Me.lstBoxFinish.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstBoxFinish.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstBoxFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstBoxFinish.FormattingEnabled = True
        Me.lstBoxFinish.IntegralHeight = False
        Me.lstBoxFinish.ItemHeight = 16
        Me.lstBoxFinish.Location = New System.Drawing.Point(204, 249)
        Me.lstBoxFinish.Name = "lstBoxFinish"
        Me.lstBoxFinish.Size = New System.Drawing.Size(267, 121)
        Me.lstBoxFinish.TabIndex = 8
        '
        'lblColon2
        '
        Me.lblColon2.AutoSize = True
        Me.lblColon2.Font = New System.Drawing.Font("OCRA", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblColon2.Location = New System.Drawing.Point(375, 67)
        Me.lblColon2.Name = "lblColon2"
        Me.lblColon2.Size = New System.Drawing.Size(76, 67)
        Me.lblColon2.TabIndex = 7
        Me.lblColon2.Text = ":"
        '
        'lblColon1
        '
        Me.lblColon1.AutoSize = True
        Me.lblColon1.Font = New System.Drawing.Font("OCRA", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblColon1.Location = New System.Drawing.Point(215, 67)
        Me.lblColon1.Name = "lblColon1"
        Me.lblColon1.Size = New System.Drawing.Size(76, 67)
        Me.lblColon1.TabIndex = 6
        Me.lblColon1.Text = ":"
        '
        'lblMinutes
        '
        Me.lblMinutes.AutoSize = True
        Me.lblMinutes.Font = New System.Drawing.Font("OCRA", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMinutes.Location = New System.Drawing.Point(272, 67)
        Me.lblMinutes.Name = "lblMinutes"
        Me.lblMinutes.Size = New System.Drawing.Size(123, 67)
        Me.lblMinutes.TabIndex = 5
        Me.lblMinutes.Text = "00"
        '
        'lblSeconds
        '
        Me.lblSeconds.AutoSize = True
        Me.lblSeconds.Font = New System.Drawing.Font("OCRA", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSeconds.Location = New System.Drawing.Point(438, 67)
        Me.lblSeconds.Name = "lblSeconds"
        Me.lblSeconds.Size = New System.Drawing.Size(123, 67)
        Me.lblSeconds.TabIndex = 4
        Me.lblSeconds.Text = "00"
        '
        'btnReset
        '
        Me.btnReset.AutoSize = True
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(410, 178)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(99, 37)
        Me.btnReset.TabIndex = 3
        Me.btnReset.Text = "RESET"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.AutoSize = True
        Me.btnStop.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStop.Location = New System.Drawing.Point(165, 178)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(96, 35)
        Me.btnStop.TabIndex = 2
        Me.btnStop.Text = "START"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'lblHours
        '
        Me.lblHours.AutoSize = True
        Me.lblHours.Font = New System.Drawing.Font("OCRA", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHours.Location = New System.Drawing.Point(113, 67)
        Me.lblHours.Name = "lblHours"
        Me.lblHours.Size = New System.Drawing.Size(123, 67)
        Me.lblHours.TabIndex = 0
        Me.lblHours.Text = "00"
        '
        'tabStandings
        '
        Me.tabStandings.Controls.Add(Me.Label1)
        Me.tabStandings.Controls.Add(Me.picBox2ndPlace)
        Me.tabStandings.Controls.Add(Me.picBox3rdPlace)
        Me.tabStandings.Controls.Add(Me.picBox4thPlace)
        Me.tabStandings.Controls.Add(Me.picBox5thPlace)
        Me.tabStandings.Controls.Add(Me.picBox6thPlace)
        Me.tabStandings.Controls.Add(Me.picBox7thPlace)
        Me.tabStandings.Controls.Add(Me.picBox8thPlace)
        Me.tabStandings.Controls.Add(Me.picBox9thPlace)
        Me.tabStandings.Controls.Add(Me.picBox10thPlace)
        Me.tabStandings.Controls.Add(Me.picBox1stPlace)
        Me.tabStandings.Controls.Add(Me.lbl10thCol)
        Me.tabStandings.Controls.Add(Me.lbl10thColon)
        Me.tabStandings.Controls.Add(Me.lbl10thSec)
        Me.tabStandings.Controls.Add(Me.lbl10thMin)
        Me.tabStandings.Controls.Add(Me.lbl10thHr)
        Me.tabStandings.Controls.Add(Me.lbl9thCol)
        Me.tabStandings.Controls.Add(Me.lbl9thColon)
        Me.tabStandings.Controls.Add(Me.lbl9thSec)
        Me.tabStandings.Controls.Add(Me.lbl9thMin)
        Me.tabStandings.Controls.Add(Me.lbl9thHr)
        Me.tabStandings.Controls.Add(Me.lbl8thCol)
        Me.tabStandings.Controls.Add(Me.lbl8thColon)
        Me.tabStandings.Controls.Add(Me.lbl8thSec)
        Me.tabStandings.Controls.Add(Me.lbl8thMin)
        Me.tabStandings.Controls.Add(Me.lbl8thHr)
        Me.tabStandings.Controls.Add(Me.lbl7thCol)
        Me.tabStandings.Controls.Add(Me.lbl7thColon)
        Me.tabStandings.Controls.Add(Me.lbl7thSec)
        Me.tabStandings.Controls.Add(Me.lbl7thMin)
        Me.tabStandings.Controls.Add(Me.lbl7thHr)
        Me.tabStandings.Controls.Add(Me.lbl6thCol)
        Me.tabStandings.Controls.Add(Me.lbl6thColon)
        Me.tabStandings.Controls.Add(Me.lbl6thSec)
        Me.tabStandings.Controls.Add(Me.lbl6thMin)
        Me.tabStandings.Controls.Add(Me.lbl6thHr)
        Me.tabStandings.Controls.Add(Me.lbl5thCol)
        Me.tabStandings.Controls.Add(Me.lbl5thColon)
        Me.tabStandings.Controls.Add(Me.lbl5thSec)
        Me.tabStandings.Controls.Add(Me.lbl5thMin)
        Me.tabStandings.Controls.Add(Me.lbl5thHr)
        Me.tabStandings.Controls.Add(Me.lbl4thCol)
        Me.tabStandings.Controls.Add(Me.lbl4thColon)
        Me.tabStandings.Controls.Add(Me.lbl4thSec)
        Me.tabStandings.Controls.Add(Me.lbl4thMin)
        Me.tabStandings.Controls.Add(Me.lbl4thHr)
        Me.tabStandings.Controls.Add(Me.lbl3rdCol)
        Me.tabStandings.Controls.Add(Me.lbl3rdColon)
        Me.tabStandings.Controls.Add(Me.lbl3rdSec)
        Me.tabStandings.Controls.Add(Me.lbl3rdMin)
        Me.tabStandings.Controls.Add(Me.lbl3rdHr)
        Me.tabStandings.Controls.Add(Me.lbl2ndCol)
        Me.tabStandings.Controls.Add(Me.lbl2ndColon)
        Me.tabStandings.Controls.Add(Me.lbl2ndSec)
        Me.tabStandings.Controls.Add(Me.lbl2ndMin)
        Me.tabStandings.Controls.Add(Me.lbl2ndHr)
        Me.tabStandings.Controls.Add(Me.lbl1stCol)
        Me.tabStandings.Controls.Add(Me.lbl1stColon)
        Me.tabStandings.Controls.Add(Me.lbl1stSec)
        Me.tabStandings.Controls.Add(Me.lbl1stMin)
        Me.tabStandings.Controls.Add(Me.lbl1stHr)
        Me.tabStandings.Controls.Add(Me.txt6thName)
        Me.tabStandings.Controls.Add(Me.txt7thName)
        Me.tabStandings.Controls.Add(Me.txt8thName)
        Me.tabStandings.Controls.Add(Me.txt9thName)
        Me.tabStandings.Controls.Add(Me.txt10thName)
        Me.tabStandings.Controls.Add(Me.txt4thName)
        Me.tabStandings.Controls.Add(Me.txt5thName)
        Me.tabStandings.Controls.Add(Me.txt3rdName)
        Me.tabStandings.Controls.Add(Me.txt2ndName)
        Me.tabStandings.Controls.Add(Me.txt1stName)
        Me.tabStandings.Controls.Add(Me.lbl10thPlace)
        Me.tabStandings.Controls.Add(Me.lbl9thPlace)
        Me.tabStandings.Controls.Add(Me.lbl8thPlace)
        Me.tabStandings.Controls.Add(Me.lbl7thPlace)
        Me.tabStandings.Controls.Add(Me.lbl6thPlace)
        Me.tabStandings.Controls.Add(Me.lbl5thPlace)
        Me.tabStandings.Controls.Add(Me.lbl4thPlace)
        Me.tabStandings.Controls.Add(Me.lbl3rdPlace)
        Me.tabStandings.Controls.Add(Me.lbl2ndPlace)
        Me.tabStandings.Controls.Add(Me.lbl1stPlace)
        Me.tabStandings.Location = New System.Drawing.Point(4, 22)
        Me.tabStandings.Name = "tabStandings"
        Me.tabStandings.Padding = New System.Windows.Forms.Padding(3)
        Me.tabStandings.Size = New System.Drawing.Size(674, 565)
        Me.tabStandings.TabIndex = 2
        Me.tabStandings.Text = "Standings"
        Me.tabStandings.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(198, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(278, 25)
        Me.Label1.TabIndex = 80
        Me.Label1.Text = "Congratulations Winners!"
        '
        'picBox2ndPlace
        '
        Me.picBox2ndPlace.Location = New System.Drawing.Point(525, 104)
        Me.picBox2ndPlace.Name = "picBox2ndPlace"
        Me.picBox2ndPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox2ndPlace.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBox2ndPlace.TabIndex = 79
        Me.picBox2ndPlace.TabStop = False
        '
        'picBox3rdPlace
        '
        Me.picBox3rdPlace.Location = New System.Drawing.Point(525, 140)
        Me.picBox3rdPlace.Name = "picBox3rdPlace"
        Me.picBox3rdPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox3rdPlace.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBox3rdPlace.TabIndex = 78
        Me.picBox3rdPlace.TabStop = False
        '
        'picBox4thPlace
        '
        Me.picBox4thPlace.Location = New System.Drawing.Point(525, 177)
        Me.picBox4thPlace.Name = "picBox4thPlace"
        Me.picBox4thPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox4thPlace.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBox4thPlace.TabIndex = 77
        Me.picBox4thPlace.TabStop = False
        '
        'picBox5thPlace
        '
        Me.picBox5thPlace.Location = New System.Drawing.Point(525, 213)
        Me.picBox5thPlace.Name = "picBox5thPlace"
        Me.picBox5thPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox5thPlace.TabIndex = 76
        Me.picBox5thPlace.TabStop = False
        '
        'picBox6thPlace
        '
        Me.picBox6thPlace.Location = New System.Drawing.Point(525, 250)
        Me.picBox6thPlace.Name = "picBox6thPlace"
        Me.picBox6thPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox6thPlace.TabIndex = 75
        Me.picBox6thPlace.TabStop = False
        '
        'picBox7thPlace
        '
        Me.picBox7thPlace.Location = New System.Drawing.Point(525, 287)
        Me.picBox7thPlace.Name = "picBox7thPlace"
        Me.picBox7thPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox7thPlace.TabIndex = 74
        Me.picBox7thPlace.TabStop = False
        '
        'picBox8thPlace
        '
        Me.picBox8thPlace.Location = New System.Drawing.Point(525, 325)
        Me.picBox8thPlace.Name = "picBox8thPlace"
        Me.picBox8thPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox8thPlace.TabIndex = 73
        Me.picBox8thPlace.TabStop = False
        '
        'picBox9thPlace
        '
        Me.picBox9thPlace.Location = New System.Drawing.Point(525, 363)
        Me.picBox9thPlace.Name = "picBox9thPlace"
        Me.picBox9thPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox9thPlace.TabIndex = 72
        Me.picBox9thPlace.TabStop = False
        '
        'picBox10thPlace
        '
        Me.picBox10thPlace.Location = New System.Drawing.Point(525, 400)
        Me.picBox10thPlace.Name = "picBox10thPlace"
        Me.picBox10thPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox10thPlace.TabIndex = 71
        Me.picBox10thPlace.TabStop = False
        '
        'picBox1stPlace
        '
        Me.picBox1stPlace.ImageLocation = ""
        Me.picBox1stPlace.Location = New System.Drawing.Point(525, 66)
        Me.picBox1stPlace.Name = "picBox1stPlace"
        Me.picBox1stPlace.Size = New System.Drawing.Size(72, 31)
        Me.picBox1stPlace.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBox1stPlace.TabIndex = 70
        Me.picBox1stPlace.TabStop = False
        '
        'lbl10thCol
        '
        Me.lbl10thCol.AutoSize = True
        Me.lbl10thCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10thCol.Location = New System.Drawing.Point(189, 405)
        Me.lbl10thCol.Name = "lbl10thCol"
        Me.lbl10thCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl10thCol.TabIndex = 69
        Me.lbl10thCol.Text = ":"
        '
        'lbl10thColon
        '
        Me.lbl10thColon.AutoSize = True
        Me.lbl10thColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10thColon.Location = New System.Drawing.Point(162, 405)
        Me.lbl10thColon.Name = "lbl10thColon"
        Me.lbl10thColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl10thColon.TabIndex = 68
        Me.lbl10thColon.Text = ":"
        '
        'lbl10thSec
        '
        Me.lbl10thSec.AutoSize = True
        Me.lbl10thSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10thSec.Location = New System.Drawing.Point(198, 406)
        Me.lbl10thSec.Name = "lbl10thSec"
        Me.lbl10thSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl10thSec.TabIndex = 67
        Me.lbl10thSec.Text = "00"
        '
        'lbl10thMin
        '
        Me.lbl10thMin.AutoSize = True
        Me.lbl10thMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10thMin.Location = New System.Drawing.Point(171, 406)
        Me.lbl10thMin.Name = "lbl10thMin"
        Me.lbl10thMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl10thMin.TabIndex = 66
        Me.lbl10thMin.Text = "00"
        '
        'lbl10thHr
        '
        Me.lbl10thHr.AutoSize = True
        Me.lbl10thHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10thHr.Location = New System.Drawing.Point(144, 406)
        Me.lbl10thHr.Name = "lbl10thHr"
        Me.lbl10thHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl10thHr.TabIndex = 65
        Me.lbl10thHr.Text = "00"
        '
        'lbl9thCol
        '
        Me.lbl9thCol.AutoSize = True
        Me.lbl9thCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9thCol.Location = New System.Drawing.Point(189, 369)
        Me.lbl9thCol.Name = "lbl9thCol"
        Me.lbl9thCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl9thCol.TabIndex = 64
        Me.lbl9thCol.Text = ":"
        '
        'lbl9thColon
        '
        Me.lbl9thColon.AutoSize = True
        Me.lbl9thColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9thColon.Location = New System.Drawing.Point(162, 369)
        Me.lbl9thColon.Name = "lbl9thColon"
        Me.lbl9thColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl9thColon.TabIndex = 63
        Me.lbl9thColon.Text = ":"
        '
        'lbl9thSec
        '
        Me.lbl9thSec.AutoSize = True
        Me.lbl9thSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9thSec.Location = New System.Drawing.Point(198, 370)
        Me.lbl9thSec.Name = "lbl9thSec"
        Me.lbl9thSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl9thSec.TabIndex = 62
        Me.lbl9thSec.Text = "00"
        '
        'lbl9thMin
        '
        Me.lbl9thMin.AutoSize = True
        Me.lbl9thMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9thMin.Location = New System.Drawing.Point(171, 370)
        Me.lbl9thMin.Name = "lbl9thMin"
        Me.lbl9thMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl9thMin.TabIndex = 61
        Me.lbl9thMin.Text = "00"
        '
        'lbl9thHr
        '
        Me.lbl9thHr.AutoSize = True
        Me.lbl9thHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9thHr.Location = New System.Drawing.Point(144, 370)
        Me.lbl9thHr.Name = "lbl9thHr"
        Me.lbl9thHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl9thHr.TabIndex = 60
        Me.lbl9thHr.Text = "00"
        '
        'lbl8thCol
        '
        Me.lbl8thCol.AutoSize = True
        Me.lbl8thCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8thCol.Location = New System.Drawing.Point(189, 331)
        Me.lbl8thCol.Name = "lbl8thCol"
        Me.lbl8thCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl8thCol.TabIndex = 59
        Me.lbl8thCol.Text = ":"
        '
        'lbl8thColon
        '
        Me.lbl8thColon.AutoSize = True
        Me.lbl8thColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8thColon.Location = New System.Drawing.Point(162, 331)
        Me.lbl8thColon.Name = "lbl8thColon"
        Me.lbl8thColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl8thColon.TabIndex = 58
        Me.lbl8thColon.Text = ":"
        '
        'lbl8thSec
        '
        Me.lbl8thSec.AutoSize = True
        Me.lbl8thSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8thSec.Location = New System.Drawing.Point(198, 332)
        Me.lbl8thSec.Name = "lbl8thSec"
        Me.lbl8thSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl8thSec.TabIndex = 57
        Me.lbl8thSec.Text = "00"
        '
        'lbl8thMin
        '
        Me.lbl8thMin.AutoSize = True
        Me.lbl8thMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8thMin.Location = New System.Drawing.Point(171, 332)
        Me.lbl8thMin.Name = "lbl8thMin"
        Me.lbl8thMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl8thMin.TabIndex = 56
        Me.lbl8thMin.Text = "00"
        '
        'lbl8thHr
        '
        Me.lbl8thHr.AutoSize = True
        Me.lbl8thHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8thHr.Location = New System.Drawing.Point(144, 332)
        Me.lbl8thHr.Name = "lbl8thHr"
        Me.lbl8thHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl8thHr.TabIndex = 55
        Me.lbl8thHr.Text = "00"
        '
        'lbl7thCol
        '
        Me.lbl7thCol.AutoSize = True
        Me.lbl7thCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7thCol.Location = New System.Drawing.Point(189, 294)
        Me.lbl7thCol.Name = "lbl7thCol"
        Me.lbl7thCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl7thCol.TabIndex = 54
        Me.lbl7thCol.Text = ":"
        '
        'lbl7thColon
        '
        Me.lbl7thColon.AutoSize = True
        Me.lbl7thColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7thColon.Location = New System.Drawing.Point(162, 294)
        Me.lbl7thColon.Name = "lbl7thColon"
        Me.lbl7thColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl7thColon.TabIndex = 53
        Me.lbl7thColon.Text = ":"
        '
        'lbl7thSec
        '
        Me.lbl7thSec.AutoSize = True
        Me.lbl7thSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7thSec.Location = New System.Drawing.Point(198, 295)
        Me.lbl7thSec.Name = "lbl7thSec"
        Me.lbl7thSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl7thSec.TabIndex = 52
        Me.lbl7thSec.Text = "00"
        '
        'lbl7thMin
        '
        Me.lbl7thMin.AutoSize = True
        Me.lbl7thMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7thMin.Location = New System.Drawing.Point(171, 295)
        Me.lbl7thMin.Name = "lbl7thMin"
        Me.lbl7thMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl7thMin.TabIndex = 51
        Me.lbl7thMin.Text = "00"
        '
        'lbl7thHr
        '
        Me.lbl7thHr.AutoSize = True
        Me.lbl7thHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7thHr.Location = New System.Drawing.Point(144, 295)
        Me.lbl7thHr.Name = "lbl7thHr"
        Me.lbl7thHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl7thHr.TabIndex = 50
        Me.lbl7thHr.Text = "00"
        '
        'lbl6thCol
        '
        Me.lbl6thCol.AutoSize = True
        Me.lbl6thCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6thCol.Location = New System.Drawing.Point(189, 257)
        Me.lbl6thCol.Name = "lbl6thCol"
        Me.lbl6thCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl6thCol.TabIndex = 49
        Me.lbl6thCol.Text = ":"
        '
        'lbl6thColon
        '
        Me.lbl6thColon.AutoSize = True
        Me.lbl6thColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6thColon.Location = New System.Drawing.Point(162, 257)
        Me.lbl6thColon.Name = "lbl6thColon"
        Me.lbl6thColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl6thColon.TabIndex = 48
        Me.lbl6thColon.Text = ":"
        '
        'lbl6thSec
        '
        Me.lbl6thSec.AutoSize = True
        Me.lbl6thSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6thSec.Location = New System.Drawing.Point(198, 258)
        Me.lbl6thSec.Name = "lbl6thSec"
        Me.lbl6thSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl6thSec.TabIndex = 47
        Me.lbl6thSec.Text = "00"
        '
        'lbl6thMin
        '
        Me.lbl6thMin.AutoSize = True
        Me.lbl6thMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6thMin.Location = New System.Drawing.Point(171, 258)
        Me.lbl6thMin.Name = "lbl6thMin"
        Me.lbl6thMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl6thMin.TabIndex = 46
        Me.lbl6thMin.Text = "00"
        '
        'lbl6thHr
        '
        Me.lbl6thHr.AutoSize = True
        Me.lbl6thHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6thHr.Location = New System.Drawing.Point(144, 258)
        Me.lbl6thHr.Name = "lbl6thHr"
        Me.lbl6thHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl6thHr.TabIndex = 45
        Me.lbl6thHr.Text = "00"
        '
        'lbl5thCol
        '
        Me.lbl5thCol.AutoSize = True
        Me.lbl5thCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5thCol.Location = New System.Drawing.Point(189, 220)
        Me.lbl5thCol.Name = "lbl5thCol"
        Me.lbl5thCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl5thCol.TabIndex = 44
        Me.lbl5thCol.Text = ":"
        '
        'lbl5thColon
        '
        Me.lbl5thColon.AutoSize = True
        Me.lbl5thColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5thColon.Location = New System.Drawing.Point(162, 220)
        Me.lbl5thColon.Name = "lbl5thColon"
        Me.lbl5thColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl5thColon.TabIndex = 43
        Me.lbl5thColon.Text = ":"
        '
        'lbl5thSec
        '
        Me.lbl5thSec.AutoSize = True
        Me.lbl5thSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5thSec.Location = New System.Drawing.Point(198, 221)
        Me.lbl5thSec.Name = "lbl5thSec"
        Me.lbl5thSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl5thSec.TabIndex = 42
        Me.lbl5thSec.Text = "00"
        '
        'lbl5thMin
        '
        Me.lbl5thMin.AutoSize = True
        Me.lbl5thMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5thMin.Location = New System.Drawing.Point(171, 221)
        Me.lbl5thMin.Name = "lbl5thMin"
        Me.lbl5thMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl5thMin.TabIndex = 41
        Me.lbl5thMin.Text = "00"
        '
        'lbl5thHr
        '
        Me.lbl5thHr.AutoSize = True
        Me.lbl5thHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5thHr.Location = New System.Drawing.Point(144, 221)
        Me.lbl5thHr.Name = "lbl5thHr"
        Me.lbl5thHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl5thHr.TabIndex = 40
        Me.lbl5thHr.Text = "00"
        '
        'lbl4thCol
        '
        Me.lbl4thCol.AutoSize = True
        Me.lbl4thCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4thCol.Location = New System.Drawing.Point(189, 183)
        Me.lbl4thCol.Name = "lbl4thCol"
        Me.lbl4thCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl4thCol.TabIndex = 39
        Me.lbl4thCol.Text = ":"
        '
        'lbl4thColon
        '
        Me.lbl4thColon.AutoSize = True
        Me.lbl4thColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4thColon.Location = New System.Drawing.Point(162, 183)
        Me.lbl4thColon.Name = "lbl4thColon"
        Me.lbl4thColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl4thColon.TabIndex = 38
        Me.lbl4thColon.Text = ":"
        '
        'lbl4thSec
        '
        Me.lbl4thSec.AutoSize = True
        Me.lbl4thSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4thSec.Location = New System.Drawing.Point(198, 184)
        Me.lbl4thSec.Name = "lbl4thSec"
        Me.lbl4thSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl4thSec.TabIndex = 37
        Me.lbl4thSec.Text = "00"
        '
        'lbl4thMin
        '
        Me.lbl4thMin.AutoSize = True
        Me.lbl4thMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4thMin.Location = New System.Drawing.Point(171, 184)
        Me.lbl4thMin.Name = "lbl4thMin"
        Me.lbl4thMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl4thMin.TabIndex = 36
        Me.lbl4thMin.Text = "00"
        '
        'lbl4thHr
        '
        Me.lbl4thHr.AutoSize = True
        Me.lbl4thHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4thHr.Location = New System.Drawing.Point(144, 184)
        Me.lbl4thHr.Name = "lbl4thHr"
        Me.lbl4thHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl4thHr.TabIndex = 35
        Me.lbl4thHr.Text = "00"
        '
        'lbl3rdCol
        '
        Me.lbl3rdCol.AutoSize = True
        Me.lbl3rdCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3rdCol.Location = New System.Drawing.Point(189, 147)
        Me.lbl3rdCol.Name = "lbl3rdCol"
        Me.lbl3rdCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl3rdCol.TabIndex = 34
        Me.lbl3rdCol.Text = ":"
        '
        'lbl3rdColon
        '
        Me.lbl3rdColon.AutoSize = True
        Me.lbl3rdColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3rdColon.Location = New System.Drawing.Point(162, 147)
        Me.lbl3rdColon.Name = "lbl3rdColon"
        Me.lbl3rdColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl3rdColon.TabIndex = 33
        Me.lbl3rdColon.Text = ":"
        '
        'lbl3rdSec
        '
        Me.lbl3rdSec.AutoSize = True
        Me.lbl3rdSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3rdSec.Location = New System.Drawing.Point(198, 148)
        Me.lbl3rdSec.Name = "lbl3rdSec"
        Me.lbl3rdSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl3rdSec.TabIndex = 32
        Me.lbl3rdSec.Text = "00"
        '
        'lbl3rdMin
        '
        Me.lbl3rdMin.AutoSize = True
        Me.lbl3rdMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3rdMin.Location = New System.Drawing.Point(171, 148)
        Me.lbl3rdMin.Name = "lbl3rdMin"
        Me.lbl3rdMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl3rdMin.TabIndex = 31
        Me.lbl3rdMin.Text = "00"
        '
        'lbl3rdHr
        '
        Me.lbl3rdHr.AutoSize = True
        Me.lbl3rdHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3rdHr.Location = New System.Drawing.Point(144, 148)
        Me.lbl3rdHr.Name = "lbl3rdHr"
        Me.lbl3rdHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl3rdHr.TabIndex = 30
        Me.lbl3rdHr.Text = "00"
        '
        'lbl2ndCol
        '
        Me.lbl2ndCol.AutoSize = True
        Me.lbl2ndCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndCol.Location = New System.Drawing.Point(189, 110)
        Me.lbl2ndCol.Name = "lbl2ndCol"
        Me.lbl2ndCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl2ndCol.TabIndex = 29
        Me.lbl2ndCol.Text = ":"
        '
        'lbl2ndColon
        '
        Me.lbl2ndColon.AutoSize = True
        Me.lbl2ndColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndColon.Location = New System.Drawing.Point(162, 110)
        Me.lbl2ndColon.Name = "lbl2ndColon"
        Me.lbl2ndColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl2ndColon.TabIndex = 28
        Me.lbl2ndColon.Text = ":"
        '
        'lbl2ndSec
        '
        Me.lbl2ndSec.AutoSize = True
        Me.lbl2ndSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndSec.Location = New System.Drawing.Point(199, 111)
        Me.lbl2ndSec.Name = "lbl2ndSec"
        Me.lbl2ndSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl2ndSec.TabIndex = 27
        Me.lbl2ndSec.Text = "00"
        '
        'lbl2ndMin
        '
        Me.lbl2ndMin.AutoSize = True
        Me.lbl2ndMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndMin.Location = New System.Drawing.Point(171, 111)
        Me.lbl2ndMin.Name = "lbl2ndMin"
        Me.lbl2ndMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl2ndMin.TabIndex = 26
        Me.lbl2ndMin.Text = "00"
        '
        'lbl2ndHr
        '
        Me.lbl2ndHr.AutoSize = True
        Me.lbl2ndHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndHr.Location = New System.Drawing.Point(144, 111)
        Me.lbl2ndHr.Name = "lbl2ndHr"
        Me.lbl2ndHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl2ndHr.TabIndex = 25
        Me.lbl2ndHr.Text = "00"
        '
        'lbl1stCol
        '
        Me.lbl1stCol.AutoSize = True
        Me.lbl1stCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stCol.Location = New System.Drawing.Point(189, 75)
        Me.lbl1stCol.Name = "lbl1stCol"
        Me.lbl1stCol.Size = New System.Drawing.Size(11, 16)
        Me.lbl1stCol.TabIndex = 24
        Me.lbl1stCol.Text = ":"
        '
        'lbl1stColon
        '
        Me.lbl1stColon.AutoSize = True
        Me.lbl1stColon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stColon.Location = New System.Drawing.Point(162, 75)
        Me.lbl1stColon.Name = "lbl1stColon"
        Me.lbl1stColon.Size = New System.Drawing.Size(11, 16)
        Me.lbl1stColon.TabIndex = 23
        Me.lbl1stColon.Text = ":"
        '
        'lbl1stSec
        '
        Me.lbl1stSec.AutoSize = True
        Me.lbl1stSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stSec.Location = New System.Drawing.Point(198, 76)
        Me.lbl1stSec.Name = "lbl1stSec"
        Me.lbl1stSec.Size = New System.Drawing.Size(22, 16)
        Me.lbl1stSec.TabIndex = 22
        Me.lbl1stSec.Text = "00"
        '
        'lbl1stMin
        '
        Me.lbl1stMin.AutoSize = True
        Me.lbl1stMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stMin.Location = New System.Drawing.Point(171, 76)
        Me.lbl1stMin.Name = "lbl1stMin"
        Me.lbl1stMin.Size = New System.Drawing.Size(22, 16)
        Me.lbl1stMin.TabIndex = 21
        Me.lbl1stMin.Text = "00"
        '
        'lbl1stHr
        '
        Me.lbl1stHr.AutoSize = True
        Me.lbl1stHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stHr.Location = New System.Drawing.Point(144, 76)
        Me.lbl1stHr.Name = "lbl1stHr"
        Me.lbl1stHr.Size = New System.Drawing.Size(22, 16)
        Me.lbl1stHr.TabIndex = 20
        Me.lbl1stHr.Text = "00"
        '
        'txt6thName
        '
        Me.txt6thName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt6thName.Location = New System.Drawing.Point(259, 258)
        Me.txt6thName.Name = "txt6thName"
        Me.txt6thName.Size = New System.Drawing.Size(217, 24)
        Me.txt6thName.TabIndex = 19
        '
        'txt7thName
        '
        Me.txt7thName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt7thName.Location = New System.Drawing.Point(259, 295)
        Me.txt7thName.Name = "txt7thName"
        Me.txt7thName.Size = New System.Drawing.Size(217, 24)
        Me.txt7thName.TabIndex = 18
        '
        'txt8thName
        '
        Me.txt8thName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt8thName.Location = New System.Drawing.Point(259, 332)
        Me.txt8thName.Name = "txt8thName"
        Me.txt8thName.Size = New System.Drawing.Size(217, 24)
        Me.txt8thName.TabIndex = 17
        '
        'txt9thName
        '
        Me.txt9thName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt9thName.Location = New System.Drawing.Point(259, 369)
        Me.txt9thName.Name = "txt9thName"
        Me.txt9thName.Size = New System.Drawing.Size(217, 24)
        Me.txt9thName.TabIndex = 16
        '
        'txt10thName
        '
        Me.txt10thName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt10thName.Location = New System.Drawing.Point(259, 406)
        Me.txt10thName.Name = "txt10thName"
        Me.txt10thName.Size = New System.Drawing.Size(217, 24)
        Me.txt10thName.TabIndex = 15
        '
        'txt4thName
        '
        Me.txt4thName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt4thName.Location = New System.Drawing.Point(259, 184)
        Me.txt4thName.Name = "txt4thName"
        Me.txt4thName.Size = New System.Drawing.Size(217, 24)
        Me.txt4thName.TabIndex = 14
        '
        'txt5thName
        '
        Me.txt5thName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt5thName.Location = New System.Drawing.Point(259, 218)
        Me.txt5thName.Name = "txt5thName"
        Me.txt5thName.Size = New System.Drawing.Size(217, 24)
        Me.txt5thName.TabIndex = 13
        '
        'txt3rdName
        '
        Me.txt3rdName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt3rdName.Location = New System.Drawing.Point(259, 147)
        Me.txt3rdName.Name = "txt3rdName"
        Me.txt3rdName.Size = New System.Drawing.Size(217, 24)
        Me.txt3rdName.TabIndex = 12
        '
        'txt2ndName
        '
        Me.txt2ndName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2ndName.Location = New System.Drawing.Point(259, 110)
        Me.txt2ndName.Name = "txt2ndName"
        Me.txt2ndName.Size = New System.Drawing.Size(217, 24)
        Me.txt2ndName.TabIndex = 11
        '
        'txt1stName
        '
        Me.txt1stName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1stName.Location = New System.Drawing.Point(259, 73)
        Me.txt1stName.Name = "txt1stName"
        Me.txt1stName.Size = New System.Drawing.Size(217, 24)
        Me.txt1stName.TabIndex = 10
        '
        'lbl10thPlace
        '
        Me.lbl10thPlace.AutoSize = True
        Me.lbl10thPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10thPlace.Location = New System.Drawing.Point(47, 406)
        Me.lbl10thPlace.Name = "lbl10thPlace"
        Me.lbl10thPlace.Size = New System.Drawing.Size(73, 16)
        Me.lbl10thPlace.TabIndex = 9
        Me.lbl10thPlace.Text = "10th Place:"
        '
        'lbl9thPlace
        '
        Me.lbl9thPlace.AutoSize = True
        Me.lbl9thPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9thPlace.Location = New System.Drawing.Point(54, 369)
        Me.lbl9thPlace.Name = "lbl9thPlace"
        Me.lbl9thPlace.Size = New System.Drawing.Size(66, 16)
        Me.lbl9thPlace.TabIndex = 8
        Me.lbl9thPlace.Text = "9th Place:"
        '
        'lbl8thPlace
        '
        Me.lbl8thPlace.AutoSize = True
        Me.lbl8thPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8thPlace.Location = New System.Drawing.Point(54, 332)
        Me.lbl8thPlace.Name = "lbl8thPlace"
        Me.lbl8thPlace.Size = New System.Drawing.Size(66, 16)
        Me.lbl8thPlace.TabIndex = 7
        Me.lbl8thPlace.Text = "8th Place:"
        '
        'lbl7thPlace
        '
        Me.lbl7thPlace.AutoSize = True
        Me.lbl7thPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7thPlace.Location = New System.Drawing.Point(54, 295)
        Me.lbl7thPlace.Name = "lbl7thPlace"
        Me.lbl7thPlace.Size = New System.Drawing.Size(66, 16)
        Me.lbl7thPlace.TabIndex = 6
        Me.lbl7thPlace.Text = "7th Place:"
        '
        'lbl6thPlace
        '
        Me.lbl6thPlace.AutoSize = True
        Me.lbl6thPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6thPlace.Location = New System.Drawing.Point(54, 258)
        Me.lbl6thPlace.Name = "lbl6thPlace"
        Me.lbl6thPlace.Size = New System.Drawing.Size(66, 16)
        Me.lbl6thPlace.TabIndex = 5
        Me.lbl6thPlace.Text = "6th Place:"
        '
        'lbl5thPlace
        '
        Me.lbl5thPlace.AutoSize = True
        Me.lbl5thPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5thPlace.Location = New System.Drawing.Point(51, 221)
        Me.lbl5thPlace.Name = "lbl5thPlace"
        Me.lbl5thPlace.Size = New System.Drawing.Size(69, 16)
        Me.lbl5thPlace.TabIndex = 4
        Me.lbl5thPlace.Text = " 5th Place:"
        '
        'lbl4thPlace
        '
        Me.lbl4thPlace.AutoSize = True
        Me.lbl4thPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4thPlace.Location = New System.Drawing.Point(54, 184)
        Me.lbl4thPlace.Name = "lbl4thPlace"
        Me.lbl4thPlace.Size = New System.Drawing.Size(66, 16)
        Me.lbl4thPlace.TabIndex = 3
        Me.lbl4thPlace.Text = "4th Place:"
        '
        'lbl3rdPlace
        '
        Me.lbl3rdPlace.AutoSize = True
        Me.lbl3rdPlace.BackColor = System.Drawing.Color.Peru
        Me.lbl3rdPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3rdPlace.Location = New System.Drawing.Point(31, 147)
        Me.lbl3rdPlace.Name = "lbl3rdPlace"
        Me.lbl3rdPlace.Size = New System.Drawing.Size(89, 20)
        Me.lbl3rdPlace.TabIndex = 2
        Me.lbl3rdPlace.Text = "3rd Place:"
        '
        'lbl2ndPlace
        '
        Me.lbl2ndPlace.AutoSize = True
        Me.lbl2ndPlace.BackColor = System.Drawing.Color.Silver
        Me.lbl2ndPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2ndPlace.Location = New System.Drawing.Point(27, 111)
        Me.lbl2ndPlace.Name = "lbl2ndPlace"
        Me.lbl2ndPlace.Size = New System.Drawing.Size(93, 20)
        Me.lbl2ndPlace.TabIndex = 1
        Me.lbl2ndPlace.Text = "2nd Place:"
        '
        'lbl1stPlace
        '
        Me.lbl1stPlace.AutoSize = True
        Me.lbl1stPlace.BackColor = System.Drawing.Color.Gold
        Me.lbl1stPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1stPlace.Location = New System.Drawing.Point(32, 73)
        Me.lbl1stPlace.Name = "lbl1stPlace"
        Me.lbl1stPlace.Size = New System.Drawing.Size(88, 20)
        Me.lbl1stPlace.TabIndex = 0
        Me.lbl1stPlace.Text = "1st Place:"
        '
        'timer1
        '
        '
        'imageList
        '
        Me.imageList.ImageStream = CType(resources.GetObject("imageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imageList.TransparentColor = System.Drawing.Color.Transparent
        Me.imageList.Images.SetKeyName(0, "Argentina")
        Me.imageList.Images.SetKeyName(1, "Brazil")
        Me.imageList.Images.SetKeyName(2, "Canada")
        Me.imageList.Images.SetKeyName(3, "China")
        Me.imageList.Images.SetKeyName(4, "Jamaica")
        Me.imageList.Images.SetKeyName(5, "Mexico")
        Me.imageList.Images.SetKeyName(6, "Netherlands")
        Me.imageList.Images.SetKeyName(7, "Russia")
        Me.imageList.Images.SetKeyName(8, "SouthAfrica")
        Me.imageList.Images.SetKeyName(9, "USA")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(682, 591)
        Me.Controls.Add(Me.tabControl1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Stopwatch"
        Me.tabControl1.ResumeLayout(False)
        Me.tabAthlete.ResumeLayout(False)
        Me.tabAthlete.PerformLayout()
        Me.grpAthletes.ResumeLayout(False)
        Me.grpAthletes.PerformLayout()
        Me.tabRankings.ResumeLayout(False)
        Me.tabRankings.PerformLayout()
        Me.tabStandings.ResumeLayout(False)
        Me.tabStandings.PerformLayout()
        CType(Me.picBox2ndPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox3rdPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox4thPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox5thPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox6thPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox7thPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox8thPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox9thPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox10thPlace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox1stPlace, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents tabControl1 As TabControl
    Friend WithEvents tabRankings As TabPage
    Friend WithEvents tabStandings As TabPage
    Friend WithEvents btnReset As Button
    Friend WithEvents btnStop As Button
    Friend WithEvents lblHours As Label
    Friend WithEvents timer1 As Timer
    Friend WithEvents lblColon2 As Label
    Friend WithEvents lblColon1 As Label
    Friend WithEvents lblMinutes As Label
    Friend WithEvents lblSeconds As Label
    Friend WithEvents lbl3rdPlace As Label
    Friend WithEvents lbl2ndPlace As Label
    Friend WithEvents lbl1stPlace As Label
    Friend WithEvents txt6thName As TextBox
    Friend WithEvents txt7thName As TextBox
    Friend WithEvents txt8thName As TextBox
    Friend WithEvents txt9thName As TextBox
    Friend WithEvents txt10thName As TextBox
    Friend WithEvents txt4thName As TextBox
    Friend WithEvents txt5thName As TextBox
    Friend WithEvents txt3rdName As TextBox
    Friend WithEvents txt2ndName As TextBox
    Friend WithEvents txt1stName As TextBox
    Friend WithEvents lbl10thPlace As Label
    Friend WithEvents lbl9thPlace As Label
    Friend WithEvents lbl8thPlace As Label
    Friend WithEvents lbl7thPlace As Label
    Friend WithEvents lbl6thPlace As Label
    Friend WithEvents lbl5thPlace As Label
    Friend WithEvents lbl4thPlace As Label
    Friend WithEvents picBox2ndPlace As PictureBox
    Friend WithEvents picBox3rdPlace As PictureBox
    Friend WithEvents picBox4thPlace As PictureBox
    Friend WithEvents picBox5thPlace As PictureBox
    Friend WithEvents picBox6thPlace As PictureBox
    Friend WithEvents picBox7thPlace As PictureBox
    Friend WithEvents picBox8thPlace As PictureBox
    Friend WithEvents picBox9thPlace As PictureBox
    Friend WithEvents picBox10thPlace As PictureBox
    Friend WithEvents picBox1stPlace As PictureBox
    Friend WithEvents lbl10thCol As Label
    Friend WithEvents lbl10thColon As Label
    Friend WithEvents lbl10thSec As Label
    Friend WithEvents lbl10thMin As Label
    Friend WithEvents lbl10thHr As Label
    Friend WithEvents lbl9thCol As Label
    Friend WithEvents lbl9thColon As Label
    Friend WithEvents lbl9thSec As Label
    Friend WithEvents lbl9thMin As Label
    Friend WithEvents lbl9thHr As Label
    Friend WithEvents lbl8thCol As Label
    Friend WithEvents lbl8thColon As Label
    Friend WithEvents lbl8thSec As Label
    Friend WithEvents lbl8thMin As Label
    Friend WithEvents lbl8thHr As Label
    Friend WithEvents lbl7thCol As Label
    Friend WithEvents lbl7thColon As Label
    Friend WithEvents lbl7thSec As Label
    Friend WithEvents lbl7thMin As Label
    Friend WithEvents lbl7thHr As Label
    Friend WithEvents lbl6thCol As Label
    Friend WithEvents lbl6thColon As Label
    Friend WithEvents lbl6thSec As Label
    Friend WithEvents lbl6thMin As Label
    Friend WithEvents lbl6thHr As Label
    Friend WithEvents lbl5thCol As Label
    Friend WithEvents lbl5thColon As Label
    Friend WithEvents lbl5thSec As Label
    Friend WithEvents lbl5thMin As Label
    Friend WithEvents lbl5thHr As Label
    Friend WithEvents lbl4thCol As Label
    Friend WithEvents lbl4thColon As Label
    Friend WithEvents lbl4thSec As Label
    Friend WithEvents lbl4thMin As Label
    Friend WithEvents lbl4thHr As Label
    Friend WithEvents lbl3rdCol As Label
    Friend WithEvents lbl3rdColon As Label
    Friend WithEvents lbl3rdSec As Label
    Friend WithEvents lbl3rdMin As Label
    Friend WithEvents lbl3rdHr As Label
    Friend WithEvents lbl2ndCol As Label
    Friend WithEvents lbl2ndColon As Label
    Friend WithEvents lbl2ndSec As Label
    Friend WithEvents lbl2ndMin As Label
    Friend WithEvents lbl2ndHr As Label
    Friend WithEvents lbl1stCol As Label
    Friend WithEvents lbl1stColon As Label
    Friend WithEvents lbl1stSec As Label
    Friend WithEvents lbl1stMin As Label
    Friend WithEvents lbl1stHr As Label
    Friend WithEvents lstBoxFinish As ListBox
    Friend WithEvents tabAthlete As TabPage
    Friend WithEvents grpAthletes As GroupBox
    Friend WithEvents lblSelectAth As Label
    Friend WithEvents rdoNoOfAthBtn10 As RadioButton
    Friend WithEvents rdoNoOfAthBtn9 As RadioButton
    Friend WithEvents rdoNoOfAthBtn8 As RadioButton
    Friend WithEvents rdoNoOfAthBtn7 As RadioButton
    Friend WithEvents rdoNoOfAthBtn6 As RadioButton
    Friend WithEvents rdoNoOfAthBtn5 As RadioButton
    Friend WithEvents rdoNoOfAthBtn4 As RadioButton
    Friend WithEvents rdoNoOfAthBtn3 As RadioButton
    Friend WithEvents rdoNoOfAthBtn2 As RadioButton
    Friend WithEvents rdoNoOfAthBtn1 As RadioButton
    Friend WithEvents lblCountyheading As Label
    Friend WithEvents lblAthheading As Label
    Friend WithEvents txtBoxAthName10 As TextBox
    Friend WithEvents txtBoxAthName9 As TextBox
    Friend WithEvents txtBoxAthName8 As TextBox
    Friend WithEvents txtBoxAthName7 As TextBox
    Friend WithEvents txtBoxAthName6 As TextBox
    Friend WithEvents txtBoxAthName5 As TextBox
    Friend WithEvents txtBoxAthName4 As TextBox
    Friend WithEvents txtBoxAthName3 As TextBox
    Friend WithEvents txtBoxAthName2 As TextBox
    Friend WithEvents txtBoxAthName1 As TextBox
    Friend WithEvents btnMark As Button
    Friend WithEvents btnAwards As Button
    Friend WithEvents cboBoxCtyAth1 As ComboBox
    Friend WithEvents imageList As ImageList
    Friend WithEvents cboBoxCtyAth2 As ComboBox
    Friend WithEvents cboBoxCtyAth3 As ComboBox
    Friend WithEvents cboBoxCtyAth4 As ComboBox
    Friend WithEvents cboBoxCtyAth10 As ComboBox
    Friend WithEvents cboBoxCtyAth9 As ComboBox
    Friend WithEvents cboBoxCtyAth8 As ComboBox
    Friend WithEvents cboBoxCtyAth7 As ComboBox
    Friend WithEvents cboBoxCtyAth6 As ComboBox
    Friend WithEvents cboBoxCtyAth5 As ComboBox
    Friend WithEvents Label1 As Label
End Class
